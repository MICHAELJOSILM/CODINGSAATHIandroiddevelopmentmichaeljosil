package com.example.converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputEditText;
    private Button convertButton;
    private TextView resultTextView;
    private Spinner conversionSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputEditText = findViewById(R.id.inputEditText);
        convertButton = findViewById(R.id.convertButton);
        resultTextView = findViewById(R.id.resultTextView);
        conversionSpinner = findViewById(R.id.conversionSpinner);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String inputString = inputEditText.getText().toString().trim();
        double inputValue;

        if (inputString.isEmpty()) {
            resultTextView.setText("Please enter a value.");
            return;
        }

        try {
            inputValue = Double.parseDouble(inputString);
        } catch (NumberFormatException e) {
            resultTextView.setText("Invalid input. Please enter a valid number.");
            return;
        }

        String selectedConversion = conversionSpinner.getSelectedItem().toString();
        double result;

        switch (selectedConversion) {
            case "Miles to Kilometers":
                result = convertMilesToKilometers(inputValue);
                resultTextView.setText(inputValue + " miles = " + result + " kilometers");
                break;
            case "Kilometers to Miles":
                result = convertKilometersToMiles(inputValue);
                resultTextView.setText(inputValue + " kilometers = " + result + " miles");
                break;
            case "Pounds to Kilograms":
                result = convertPoundsToKilograms(inputValue);
                resultTextView.setText(inputValue + " pounds = " + result + " kilograms");
                break;
            case "Kilograms to Pounds":
                result = convertKilogramsToPounds(inputValue);
                resultTextView.setText(inputValue + " kilograms = " + result + " pounds");
                break;
            case "Centimeters to Meters":
                result = convertCentimetersToMeters(inputValue);
                resultTextView.setText(inputValue + " centimeters = " + result + " meters");
                break;
            // Add more cases for other conversions
            default:
                resultTextView.setText("Invalid conversion selected.");
        }
    }

    private double convertMilesToKilometers(double miles) {
        return miles * 1.60934;
    }

    private double convertKilometersToMiles(double kilometers) {
        return kilometers / 1.60934;
    }

    private double convertPoundsToKilograms(double pounds) {
        return pounds * 0.453592;
    }

    private double convertKilogramsToPounds(double kilograms) {
        return kilograms / 0.453592;
    }

    private double convertCentimetersToMeters(double centimeters) {
        return centimeters / 100;
    }

    // Add more conversion methods for other conversions

}
